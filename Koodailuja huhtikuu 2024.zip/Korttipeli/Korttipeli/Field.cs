﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Korttipeli
{
    public class Field

    {
        public List<Card> cards = new List<Card>();

        internal void playCard(Card newCard)
        {
            //max 5 creature cards
            cards.Add(newCard);
        }
    }
}

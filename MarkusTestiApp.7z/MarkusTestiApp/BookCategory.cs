﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarkusTestiApp
{
    internal class BookCategory
    {
        public int categoryType = 0;
        public List<Book> books = new List<Book>();
    }
}

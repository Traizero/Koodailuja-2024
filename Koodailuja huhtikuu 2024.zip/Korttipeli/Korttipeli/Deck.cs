﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Korttipeli
{
    public class Deck
    {
        List<Card> cards = new List<Card>();
        Random random = new Random();
        public Deck(List<Card> cards)
        {
            this.cards = cards;
        }

        internal Card drawCard()
        {
            Card card = cards[random.Next(cards.Count)];
            cards.Remove(card);
            return card;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Korttipeli
{
    public class Board
    {
        public List<Player> players = new List<Player>();
        List<GlobalEffect> globalEffects = new List<GlobalEffect>();
        int currentRound = 0;
        Player starter = null;
        Player currentTurnPlayer = null;
        static Board instance = null;
        public static Board Get() { return instance; }
        

        public Board(List<Player> players, Player starter)
        {
            this.players = players;
            this.starter = starter;
            instance = this;
        }

        public void UpdateBoard()
        {
            if (currentTurnPlayer == null)
            {
                currentTurnPlayer = starter;
                currentTurnPlayer.playTurn();
                return;
            }

            Player nextPlayer = null;
            foreach (Player player2 in players)
            {
                if (player2 != currentTurnPlayer)
                    nextPlayer = player2;
            }
            currentTurnPlayer.playTurn();
            currentTurnPlayer = nextPlayer;
            if (currentTurnPlayer == starter)
            {
                currentRound++;
            }
            if (nextPlayer.hp <= 0)
            {
                Console.WriteLine("You lost!");
            }
        }
    }
}

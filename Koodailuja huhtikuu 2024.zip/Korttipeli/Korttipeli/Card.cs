﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Korttipeli
{
    public class Card
    {
        int attack = 5;

        internal void Attack(Player player)
        {
            Board b = Board.Get();
            Player opponent = null;
            foreach (Player player2 in b.players)
            {
                if (player2 != player) 
                    opponent = player2;
            }
            opponent.hp -= attack;
            Console.WriteLine("Player"+ (opponent.index + 1) + " was attacked! Player" + (opponent.index + 1) + " lost " + (attack) + " hp!");
            

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Korttipeli
{
    public class Hand
    {
        public List<Card> cards = new List<Card>();
        
        public void addCard(Card card)
        {
            cards.Add(card);
            Console.WriteLine("Player draws a card!");
        }
    }


}

﻿// See https://aka.ms/new-console-template for more information
using Korttipeli;

Console.WriteLine("Hello, World!");


//Board 
// - Players
// - Global Effects (later, for visual)
// - turn count, whose turn, 

//Player
// - Hand (cards, list of cards)
// - Deck (cards, list of cards)
// - Graveyard (cards) (later, for visual, list of cards)
// - Field (list of cards)

//

//int heads = 1;
//int tails = 0;



Console.WriteLine("Flip a coin! Heads or Tails,");

string coinSide = Console.ReadLine();
bool isHeads = (coinSide == "heads" || coinSide == "Heads");

Random random = new Random();
int result = random.Next(0, 2);

bool player1starts = ((result == 0 && isHeads) || result == 1 && !isHeads);

List<Card> cards = new List<Card>();
for (int i = 0; i < 40; i++)
{
    cards.Add(new Card());
    Console.WriteLine("Cards were added to the deck.");
}

Player player1 = new Player(cards, 0);
Player player2 = new Player(new List<Card> (cards), 1);

Board board = new Board(new List<Player> { player1, player2 }, player1starts ? player1 : player2) ;
while (true)
{
    board.UpdateBoard();
    
}






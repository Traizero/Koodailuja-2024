﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Korttipeli
{
    public class Player
    {

        public int hp = 200;
        Deck deck = null;
        Hand hand = new Hand();
        Graveyard graveyard = new Graveyard();
        Field field = new Field();
        Player opponent = null;
        public int index = -1;

        public enum Phase
        {
            Draw,
            Play,
            Battle,
            End,
            EnemyTurn
        }

        public Phase phase = Phase.EnemyTurn;

        public Player(List<Card> cards, int index) 
        { 
            deck = new Deck(cards);
            this.index = index;
        }

        internal void playTurn()
        {
            phase = Phase.Draw;
            Card newCard = deck.drawCard();
            hand.addCard(newCard);
            phase = Phase.Play;

            List<string> playerOptions = new List<string>();

            // ask player if they want to check hand?
            if (hand.cards.Count > 0)
            {
                playerOptions.Add("Check your hand");
            }
            // ask player if they want to check field?
            if (field.cards.Count > 0)
            {
                playerOptions.Add("Check your field");
            }
            // ask player if they want to check graveyard?
            if (graveyard.cards.Count > 0)
            {
                playerOptions.Add("Check your graveyard");
            }
            // do you want to end play phase?
            playerOptions.Add("End play phase");


            //for loopilla sama mitä alanepana ja numeroilla (niin että ne on numeroitu 0-3):

            //Console.WriteLine($"Here are options: {string.Join(", ", playerOptions)}");


            // add drawn cards to the hand

            Console.WriteLine("Do you want to play 'Armed Soldier' ?");

            string input = Console.ReadLine();
            string valinta1 = input;

            if (input == "yes" || input == "y")
            {
                field.playCard(newCard);
                Console.WriteLine("Player1 played 'Armed Soldier'");
            }

            else if (input == "no" || input == "n")
            {
                Console.WriteLine("You decided not to play the card.");
            }

            Console.WriteLine("Do you want to attack this turn?");

            string input2 = Console.ReadLine();
            string valinta2 = input;

            if (input == "yes" || input == "y")
            {
                foreach (Card c in field.cards)
                {
                    c.Attack(this);
                    Console.WriteLine("Player attacks!");
                    Console.WriteLine(" Remaining Hp: " + opponent.hp);
                    
                }
            }

            else if (input == "no" || input == "n")
            {
                Console.WriteLine("You decided not to attack.");
            }




        }
    }
}
